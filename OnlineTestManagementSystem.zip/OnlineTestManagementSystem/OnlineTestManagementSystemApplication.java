package com.capgemini.OnlineTestManagementSystem;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OnlineTestManagementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(OnlineTestManagementSystemApplication.class, args);
	}

}
